using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NLog;
using NLog.Targets;
using NLog.Config;
using NLog.AWS.Logger;

namespace ServersLessWebApp
{
    public class Program
    {
        public static void Main(string[] args)
        {
            ConfigureNLog();

            Logger logger = LogManager.GetCurrentClassLogger();
            logger.Info("Sample Serverless App");
            logger.Info("Sample Serverless Before BuildWebHost");
            Console.WriteLine("===> Console Message for ServerLess");
            BuildWebHost(args).Run();
            logger.Info("Sample Serverless After BuildWebHost");
        }
        static void ConfigureNLog()
        {
            var config = new LoggingConfiguration();

            var consoleTarget = new ColoredConsoleTarget();
            config.AddTarget("console", consoleTarget);

            var awsTarget = new AWSTarget()
            {
                LogGroup = "NLog.BrokerAPI-Logs",
                Region = "us-east-1"
            };
            config.AddTarget("aws", awsTarget);

            config.LoggingRules.Add(new LoggingRule("*", NLog.LogLevel.Debug, consoleTarget));
            config.LoggingRules.Add(new LoggingRule("*", NLog.LogLevel.Debug, awsTarget));

            LogManager.Configuration = config;
        }

        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .Build();
    }
}
