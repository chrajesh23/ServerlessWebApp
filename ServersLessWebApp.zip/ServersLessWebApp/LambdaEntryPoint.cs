using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using NLog;
using NLog.Targets;
using NLog.Config;
using NLog.AWS.Logger;

namespace ServersLessWebApp
{
    /// <summary>
    /// This class extends from APIGatewayProxyFunction which contains the method FunctionHandlerAsync which is the 
    /// actual Lambda function entry point. The Lambda handler field should be set to
    /// 
    /// ServersLessWebApp::ServersLessWebApp.LambdaEntryPoint::FunctionHandlerAsync
    /// </summary>
    public class LambdaEntryPoint :
        // When using an ELB's Application Load Balancer as the event source change 
        // the base class to Amazon.Lambda.AspNetCoreServer.ApplicationLoadBalancerFunction
        Amazon.Lambda.AspNetCoreServer.APIGatewayProxyFunction
    {
        /// <summary>
        /// The builder has configuration, logging and Amazon API Gateway already configured. The startup class
        /// needs to be configured in this method using the UseStartup<>() method.
        /// </summary>
        /// <param name="builder"></param>
        protected override void Init(IWebHostBuilder builder)
        {
            ConfigureNLog();

            Logger logger = LogManager.GetCurrentClassLogger();
            logger.Info("Sample Serverless App");
            logger.Info("Sample Serverless Before BuildWebHost");
            Console.WriteLine("===> Console Message for ServerLess");

            builder
                .UseStartup<Startup>();
        }

        public void ConfigureNLog()
        {
            var config = new LoggingConfiguration();

            var consoleTarget = new ColoredConsoleTarget();
            config.AddTarget("console", consoleTarget);

            var awsTarget = new AWSTarget()
            {
                LogGroup = "NLog.BrokerAPI-Logs",
                Region = "us-east-1"
            };
            config.AddTarget("aws", awsTarget);

            config.LoggingRules.Add(new LoggingRule("*", NLog.LogLevel.Debug, consoleTarget));
            config.LoggingRules.Add(new LoggingRule("*", NLog.LogLevel.Debug, awsTarget));

            LogManager.Configuration = config;
        }
    }
}
